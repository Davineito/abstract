package org.formacion.abstractfactory;

public interface Abstrac_Factory {
	public Preguntas createPreguntas();
	public Saludos createSaludos();
}
